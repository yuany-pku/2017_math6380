# combine k-nearest-neighbors to linear regression
# GOD function produces results for k-nearest neighbors

from helpers import *
import numpy as np
from sklearn.linear_model import LinearRegression
from sklearn.feature_selection import RFECV
import matplotlib.pyplot as plt
import sys

def GOD():
    df = pd.read_csv("./onedrug_train.csv")

    table = np.array(df)

    nan_index = []
    good_index = []
    for i in range(len(table)):
        if np.isnan(table[i, 2]):
            nan_index.append(i)
        else:
            good_index.append(i)

    data = table[nan_index, :]

    def cos(v1, v2):
        norm1 = np.sqrt(np.sum(np.square(v1)))
        norm2 = np.sqrt(np.sum(np.square(v2)))
        if norm1 > 0 and norm2 > 0:
            return np.dot(v1.transpose(), v2) / (norm1 * norm2)
        else:
            return 0.

    threshold = 10
    threshold_cos = 0.6
    threshold_counter = 5
    print 'threshold %d, threshold_cos %.1f, threshold_counter %d' % (threshold, threshold_cos, threshold_counter)

    X, y = get_X_y()
    X_test = get_X_test()
    mask = get_mask(threshold)
    X = X[:, mask]
    X_test = X_test[:, mask]
    sample_num = X.shape[0]
    param_num = X.shape[1]
    ids = data[:, 0]

    dict = {}
    predict_total = 0
    for pr_ind in range(len(X_test)):
        sum = 0.
        counter = 0
        for tr_ind in range(len(X)):
            cur_cos = cos(X_test[pr_ind], X[tr_ind])
            if cur_cos >= threshold_cos:
                sum += y[tr_ind]
                counter += 1
        if counter > threshold_counter:
            predict = sum / counter
            print ids[pr_ind], predict
            dict[ids[pr_ind]] = predict
            predict_total += 1
    print predict_total

    return dict

all_X, y = get_X_y()

mask = get_mask(11)
X = all_X[:, mask]

def get_new_mask():
    clf = LinearRegression()
    rfecv = RFECV(clf, step=1, cv=3)
    selector = rfecv.fit(X, y)
    return selector.support_

mask2 = get_new_mask()
X = X[:, mask2]

lr = linear_model.LinearRegression()
lr.fit(X, y)

########
df = pd.read_csv("./onedrug_train.csv")

table = np.array(df)

nan_index = []
good_index = []
for i in range(len(table)):
    if np.isnan(table[i, 2]):
        nan_index.append(i)
    else:
        good_index.append(i)

data = table[nan_index, :]

X_test = data[:, 3:][:, mask][:, mask2]
y_test = data[:, 2]
ids = data[:, 0]

print X_test
print y_test
print ids

predict = lr.predict(X_test)

print predict

dict = GOD()
counter = 0
print '"ID","IC50"'
for i in range(len(ids)):
    if ids[i] in dict and predict[i] < 2.221503 and predict[i] > 2.221501:
        print '%d,%.6f' % (ids[i], dict[ids[i]])
        predictttt =dict[ids[i]]
    else:
        print '%d,%.6f' % (ids[i], predict[i])
        predictttt =predict[i]
    if predictttt < 2.221503 and predictttt > 2.221501:
        counter += 1
print counter