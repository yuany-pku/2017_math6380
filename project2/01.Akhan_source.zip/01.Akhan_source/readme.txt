student: Akhan Ismailov, math6380J, mini-project2, code can be found in this folder
Akhan Ismailov is only member of this team
