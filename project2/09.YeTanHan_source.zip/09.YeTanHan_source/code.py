#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Mon Apr  3 15:44:14 2017

@author: Ruijian
"""
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.preprocessing import scale
from sklearn import linear_model, cross_validation, preprocessing
from sklearn.linear_model import Ridge, RidgeCV, Lasso, LassoCV
from sklearn.metrics import mean_squared_error
from scipy import stats
import statsmodels.api as sm

# whether missing data
df = pd.read_csv("/Users/Ruijian/Desktop/222.csv").dropna().drop('name', axis=1)

dummies = pd.get_dummies(df[['price', 'police_rate1', 'sta_welf']])
#Regression:covariate: lnpolice, rincpc, econrow,citybla,sta_educ,sta_welf
X = df.drop(['year', 'sworn', 'civil','murder','rape','robbery','assault','burglary','larceny','auto'], axis=1).astype('float64')
X = X.drop(['Violent','Property','Violent_rate','Property_rate','lnvio','lnpro','police1','citypop'], axis=1).astype('float64')
X = X.drop(['police 2','police_rate1','police_rate2','div_Vio','minus_Vio'], axis=1).astype('float64')
X = X.drop(['lndiv_Vio','div_Pro','minus_Pro','lndiv_Pro'], axis=1).astype('float64')
X['citybla'] = X['citybla']/100
#X.info().'lnpolice_rate2'
Y = y = df.div_Pro
#scaler = preprocessing.StandardScaler()
#xsc = scaler.fit_transform(X)
#ysc = scaler.fit_transform(y)

xsc = X
ysc = y

alphas = 10**np.linspace(2,-3,300)
ridge = Ridge()

X_train, X_test , y_train, y_test = cross_validation.train_test_split(xsc, ysc, test_size=0.25, random_state=0)
#X_train = scale(X_train)
#X_test = scale(X_test)
#y_train = scale(y_train)
#y_test = scale(y_test)
ridge2 = Ridge(alpha=1)
ridge2.fit(X_train, y_train) 
pred2 = ridge2.predict(X_test)
(pd.Series(ridge2.coef_, index=X.columns))
(mean_squared_error(y_test, pred2))
ridgecv = RidgeCV(alphas=alphas, scoring='neg_mean_squared_error')
ridgecv.fit(X_train, y_train)
print 'min alpha value: %s' %ridgecv.alpha_
ridge4 = Ridge(alpha=ridgecv.alpha_)
ridge4.fit(X_train, y_train)
pred4 = ridge4.predict(X_test)
#mean_squared_error(y_test, ridge4.predict(X_test))

(mean_squared_error(y_test, pred4))
(pd.Series(ridge4.coef_, index=X.columns))

##try to compute pvalues

#params = np.append(ridge4.intercept_,ridge4.coef_)
#predictions = ridge4.predict(X_train)
#
#newx = pd.DataFrame({'Constant':np.ones(len(X_train))}).join(pd.DataFrame(X_train))
#mse = (sum((y_train-predictions)**2))/(len(newx)-len(newx.columns))
#
#varb  = mse*(np.linalg.inv(np.dot(newx.T,newx)).diagonal())
#sdb = np.sqrt(varb)
#tsb = params/sdb
#
#p_values = [2*(1-stats.t.cdf(np.abs(i),(len(newx)-1))) for i in tsb]
#        
#sdb = np.round(sdb, 3)
#tsb = np.round(tsb, 3)
#pvalues = np.round(p_values, 3)
#params = np.round(params, 4)
#
#mydf = pd.DataFrame()
#mydf['Coefficient'], mydf['Standard Errors'], mydf['t values'], mydf['Probabilites'] = [params, sdb, tsb, pvalues]
#print(mydf)

mod = sm.OLS(y_train,X_train)
res = mod.fit_regularized(method='coord_descent', maxiter=10000, alpha=ridgecv.alpha_, L1_wt=0)
print res.summary()
coefss=[]
for a in alphas:
        c = mod.fit_regularized(method='coord_descent', maxiter=10000, alpha=a, L1_wt=0)
        coefss.append(c.params)
np.shape(coefss)
ax = plt.gca()
ax.plot(alphas, coefss)
ax.set_xscale('log')
plt.axis('tight')
plt.xlabel('lambda')
plt.ylabel('coefficients')
