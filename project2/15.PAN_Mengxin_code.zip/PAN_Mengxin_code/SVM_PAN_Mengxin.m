% ���ɴ��ع������

x = inputtrain;
y = lnPGAtrain;

valix =inputval;
valiy =lnPGAval;

testx =inputtest;
testy =lnPGAtest;

looptime=1;

py=zeros(length(y),looptime,looptime);
mse=zeros(looptime+1,looptime+1);
Rsquare=zeros(looptime+1,looptime+1);

pvaliy=zeros(length(valiy),looptime,looptime);
valimse=zeros(looptime+1,looptime+1);
valiRsquare=zeros(looptime+1,looptime+1);
valimsePGA=zeros(looptime+1,looptime+1);

ptesty=zeros(length(valiy),looptime,looptime);
testmse=zeros(looptime+1,looptime+1);
testRsquare=zeros(looptime+1,looptime+1);


 %mape=zeros(7,7);
 
%lnPGAmse=zeros(6,6);

%predictedPGV_test=zeros(length(valiy),6,6);

% ��ģ�ع�ģ��

for j=1:looptime
    for i=1:looptime
        fprintf('iteration i: %d, j: %d \n', i, j);
        
         c=6;
         g=6;
        
        fprintf('iteration c: %d, g: %d \n', c, g);
    
        cmd = ['-c ', num2str(c), ' -g ',num2str(g), ' -h 0 -s 3 -t 2 -p 0.01'];
 
        model = libsvmtrain(y,x,cmd);
        
        mse(1,j+1)=c;
        mse(i+1,1)=g;
        Rsquare(1,j+1)=c;
        Rsquare(i+1,1)=g;
        valimse(1,j+1)=c;
        valimse(i+1,1)=g;
        valimsePGA(1,j+1)=c;
        valimsePGA(i+1,1)=g;
        valiRsquare(1,j+1)=c;
        valiRsquare(i+1,1)=g;
        testmse(1,j+1)=c;
        testmse(i+1,1)=g;
        testRsquare(1,j+1)=c;
        testRsquare(i+1,1)=g;



% ���ý�����ģ�Ϳ�����ѵ�������ϵĻع�Ч��


        [prey,premse,dec_values] = libsvmpredict(y,x,model);
%        py(:,i,j)=prey;
        mse(i+1,j+1)=premse(2);
        Rsquare(i+1,j+1)=premse(3);
% ����Ԥ��

    
        [pretesty,pretmse,dec_values_test] = libsvmpredict(valiy,valix,model);

  %      pvaliy(:,i,j)=pretesty;
        valimse(i+1,j+1)=pretmse(2);
        valiRsquare(i+1,j+1)=pretmse(3);
        
        valiPGAy=exp(valiy);
        prevaliPGA=exp(pretesty);
        valimsePGA(i+1,j+1)=(valiPGAy-prevaliPGA)'*(valiPGAy-prevaliPGA)/length(valiy);
        
      
        
        
%test set
       [pretesty,pretmse,dec_values_test] = libsvmpredict(testy,testx,model);

%        ptesty(:,i,j)=pretesty;
       testmse(i+1,j+1)=pretmse(2);
       testRsquare(i+1,j+1)=pretmse(3);
% calculate MAPE

%for z=1:length(pretesty)
  % mape(i+1,j+1)=(abs((pretesty(z)-valiY(z))/valiY(z)))/length(pretesty)+mape(i,j); 


%end

    end
end