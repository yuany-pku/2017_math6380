import numpy as np

class adaptive_ttest(object):    
    def __init__(self, limit = 10):
        self.limit = limit
        
    def fit(self, X, y, p):
        self.X = X
        self.y = y
        self.p = p
    
    def group_data(X, y):
        idx = list(range(X.shape[0]))
        group = []
        while len(idx)>0:
            standard = X[idx[0],:]
            group.append(np.array([idx[0],y[idx[0]]])[np.newaxis,:])
            del idx[0]
            if len(idx)>0:
                panel = idx.copy()
                for element in panel:
                    if sum(abs(X[element,:]-standard))==0:
                        group[-1] = np.r_[group[-1],
                              np.array([element,y[element]])[np.newaxis,:]]
                        idx.remove(element)
        num_group = len(group)
        number_element = [None]*num_group
        means = [None]*num_group
        variances = [None]*num_group
        data_pos = [None]*num_group
        for i in range(num_group):
            element = group[i]
            number_element[i] = len(element)
            means[i] = element[:,1].mean()
            variances[i] = element[:,1].var()
            data_pos[i] = int(element[0,0])
        number_element = np.array(number_element)[:,np.newaxis]
        means = np.array(means)[:,np.newaxis]
        variances = np.array(variances)[:,np.newaxis]
        data = X[data_pos,:]
        group = np.c_[number_element, means,variances, data]  
        return group
    
    def check(sample, group):
        num_group = len(group)
        data = group[:,3:]
        num_element = group[:,0]
        means = group[:,1]
        variance = group[:,2]
        for i in range(num_group):     
            if sum(abs(sample - data[i])) == 0:
                return num_element[i], means[i], variance[i]
        return 0, np.nan, np.nan
    
    def predict(self, test):
        p_thresholding = np.sort(np.unique(self.p[~np.isnan(self.p)]))
        pred = []
        for sample in test:
            for i in range(len(p_thresholding)):
                print('sample %d/%d, thresholding %d/%d.' % 
                      (len(pred), len(test)-1, i, len(p_thresholding)-1))            
                p_loc = self.p <= p_thresholding[i]
                group = adaptive_ttest.group_data(self.X[:,p_loc], self.y)
                temp_sample = sample[p_loc]
                num_same, value, var = adaptive_ttest.check(temp_sample, group)
                if num_same <= self.limit:
                    pred.append(value)
                    break
                if i == len(p_thresholding)-1:
                    pred.append(value)
        return pred
