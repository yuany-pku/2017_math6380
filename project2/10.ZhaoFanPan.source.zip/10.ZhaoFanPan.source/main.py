#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import numpy as np
import pandas as pd

#   Submission
submission = pd.read_csv('OneDrug_submission.csv')

#   Data Setting
df = pd.read_csv('OneDrug_train.csv')

train_index = df.index[np.logical_not(np.isnan(df['IC50s']))]
test_index = df.index[np.isnan(df['IC50s'])]

test = df.values[test_index,3:] # test_feature

feature = df.values[train_index,3:] # train_feature
IC50s = df.values[train_index,2]    # train_y

# feature selection
from scipy.stats import ttest_ind

ttest = [None] * feature.shape[1]
for i in range(feature.shape[1]):
    sample1 = IC50s[ feature[:,i] == 1 ]
    sample0 = IC50s[ feature[:,i] == 0 ]
    if len(sample1) > 1:
        ttest[i] = ttest_ind(sample1, sample0, equal_var = False)
    else:
        ttest[i] = [np.nan]*2
ttest = np.array(ttest)

# new ttest
from learning import adaptive_ttest
model = adaptive_ttest(limit = 15)
model.fit(feature, IC50s, ttest[:,1])
pred = model.predict(test)

submission['IC50'] = pred
submission.to_csv('adaptive_notable0.1.csv',index=False)
