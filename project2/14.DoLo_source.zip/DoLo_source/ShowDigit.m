function ShowDigit(datavec,tttxt,xltxt)
% Author: Yi-Su Lo (yloab@connect.ust.hk)
% April 2017


datamat = reshape(datavec,16,16);

imshow(datamat');

if exist('tttxt','var'), title(tttxt,'fontsize',8); end

if exist('xltxt','var'), 
    xlhan = xlabel(xltxt,'fontsize',7); 
    xlposition = get(xlhan,'Position'); xlposition(2) = 18;
    set(xlhan,'Position',xlposition);
end

end