function [sam,lab] = LoadDigitData(fpath,digits)
% Author: Yi-Su Lo (yloab@connect.ust.hk)
% April 2017


load(fpath);

nosam = 0;
for isam = 1:size(zipdata,1),
    if sum(zipdata(isam,1)==digits),
        nosam = nosam + 1;
        sam(nosam,:) = (zipdata(isam,2:257)+1)/2;    % sample
        lab(nosam,1) = zipdata(isam,1);              % label
    end    
end

% output message
for idig = 1:length(digits),
    disp(['    ',num2str(sum(lab==digits(idig))),' samples of digit ',num2str(digits(idig))]);
end
disp(['    The reading of totally ',num2str(nosam),' samples and labels is completed.']);

end