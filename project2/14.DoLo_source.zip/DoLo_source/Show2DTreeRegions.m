function Show2DTreeRegions(dtree,samsco,samlab,lab)
% Author: Yi-Su Lo (yloab@connect.ust.hk)
% April 2017


% collect all labels
nolab = length(lab);

% generate the 2D domain data 
xmin = min(samsco(:,1))*.99;  xmax = max(samsco(:,1))*1.01;
ymin = min(samsco(:,2))*.99;  ymax = max(samsco(:,2))*1.01;
[xgrid,ygrid] = meshgrid(linspace(xmin,xmax,300),linspace(ymin,ymax,300));
domdat = reshape([xgrid,ygrid],90000,2);

% classification of the domain data
domfit = predict(dtree,domdat);
if iscell(domfit), domfit = str2double(domfit); end

% output figure for regions and samples
figure;  hold on;
legtxt = cell(1,2*nolab);
for ilab = 1:nolab;
    % regions
    domdatcat = find(domfit==lab(ilab));
    cplan = .75*ones(1,3);  cplan(ilab) = 1;
    plot(domdat(domdatcat,1),domdat(domdatcat,2),'.','color',cplan);
    legtxt{ilab*2-1} = ['Region of ',num2str(lab(ilab))];
    % samples
    samcat = find(samlab==lab(ilab));
    cplan = zeros(1,3);     cplan(ilab) = 1;
    plot(samsco(samcat,1),samsco(samcat,2),'x','color',cplan);
    legtxt{ilab*2} = ['Sample of ',num2str(lab(ilab))];
end
hold off;   xlim([xmin,xmax]);  ylim([ymin,ymax]);
title('Regions and Samples');  xlabel('feature 1');  ylabel('feature 2');  
lhan = legend(legtxt);  set(lhan,'Location','southwest');

end