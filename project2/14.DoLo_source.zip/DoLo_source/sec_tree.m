% Section for decision Tree
% Author: Yi-Su Lo (yloab@connect.ust.hk)
% April 2017


%% presetting 
close all;  clear variables;
ifviewtree = 1;     % 0/1: output the tree viewer
ifshowregion = 1;   % 0/1: output the region split
ifdotest = 1;       % 0/1: classification in the test set 


%% load data

% assign the digits of interest
diglab = 0:2;

% load training data (for an illustration example, extract part of digits)
disp('Load the training set.');
[trsam,trlab] = LoadDigitData('./digits_ElemStatLearn/zipdata.train.mat',diglab);
nolab = length(diglab);
notrsam = size(trsam,1);

% reduce the dimension
nodim = 2;
disp(['Carry out PCA and make the use of ',num2str(nodim),' features.']);
[coef,trscore,~,~,trexp,trmu] = pca(trsam);
trsco = trscore(:,1:nodim);

% load test data
if ifdotest, 
    disp('Load the test set.');
    [tesam,telab] = LoadDigitData('./digits_ElemStatLearn/zipdata.test',diglab);
    notesam = size(tesam,1);
    tesam_c = tesam - repmat(trmu,notesam,1);
    tescore = tesam_c*coef;
    tesco = tescore(:,1:nodim);
end
    

%% Full tree

% grow a tree
disp('Grow the decision tree.');
rng(1); % For reproducibility
dtree = fitctree(trsco,trlab);
if ifviewtree, view(dtree,'Mode','graph'); end 
errrat = loss(dtree,trsco,trlab);
disp(['    Size of the full tree: ',num2str(dtree.NumNodes),'.']);
disp(['    The error rate in the training set: ',num2str(100*errrat,'%1.4f'),'%.']);

% draw the regions and samples
if nodim==2 && nolab<4 && ifshowregion, Show2DTreeRegions(dtree,trsco,trlab,diglab); end

% do test
if ifdotest,
    errrat = loss(dtree,tesco,telab);
    disp(['    The error rate in the test set: ',num2str(100*errrat,'%1.4f'),'%.']);
end

    
%% Pruned tree

% prune the tree: cross validation
disp('Prune the decision tree.');
rng(1);
[~,~,~,bestlevel] = cvloss(dtree,'SubTrees',0:(max(dtree.PruneList)-1),'KFold',5);
dtreepru = prune(dtree,'Level',bestlevel);
if ifviewtree, view(dtreepru,'Mode','graph'); end
errrat = loss(dtreepru,trsco,trlab);
disp(['    Size of the pruned tree: ',num2str(dtreepru.NumNodes),'.']);
disp(['    The error rate in the training set: ',num2str(100*errrat,'%1.4f'),'%.']);

% draw the regions and samples
if nodim==2 && nolab<4 && ifshowregion, Show2DTreeRegions(dtreepru,trsco,trlab,diglab); end

% do test
if ifdotest,
    errrat = loss(dtreepru,tesco,telab);
    disp(['    The error rate of in the test set: ',num2str(100*errrat,'%1.4f'),'%.']);
end


%% Bagging tree

%
notree = 100;
disp(['Bagging with ',num2str(notree),' trees begins.']);
rng(1);
dtreebag = TreeBagger(notree,trsco,trlab,'OOBPrediction','On','Method','classification','NumPredictorsToSample','all');
if ifviewtree, view(dtreebag.Trees{1},'Mode','graph'); end
%ooberrrat = oobError(dtreebag);
trfit = predict(dtreebag,trsco);
trfit = str2double(trfit);
errrat = sum(trfit~=trlab)/notrsam;
disp(['    The error rate in the training set: ',num2str(100*errrat,'%1.4f'),'%.']);

% draw the regions and samples
if nodim==2 && nolab<4 && ifshowregion, Show2DTreeRegions(dtreebag,trsco,trlab,diglab); end

%
ooberr = oobError(dtreebag);
plot(1:notree,ooberr,'o-','LineWidth',2);
xlabel('Number of trees');  ylabel('OOB error rate');  grid on;

% do test
if ifdotest,
    tefit = predict(dtreebag,tesco);
    tefit = str2double(tefit);
    errrat = sum(tefit~=telab)/notrsam;
    disp(['    The error rate in the test set: ',num2str(100*errrat,'%1.4f'),'%.']);
end


%%  Random forest

%
disp(['Random forest with ',num2str(notree),' trees begins.']);
rng(1);
dtreerf = TreeBagger(300,trsco,trlab,'OOBPrediction','On','Method','classification');
if ifviewtree, view(dtreerf.Trees{1},'Mode','graph'); end
trfit = predict(dtreerf,trsco);
trfit = str2double(trfit);
errrat = sum(trfit~=trlab)/notrsam;
disp(['    The error rate in the training set: ',num2str(100*errrat,'%1.4f'),'%.']);

% draw the regions and samples
if nodim==2 && nolab<4 && ifshowregion, Show2DTreeRegions(dtreerf,trsco,trlab,diglab); end

% do test
if ifdotest,
    tefit = predict(dtreerf,tesco);
    tefit = str2double(tefit);
    errrat = sum(tefit~=telab)/notrsam;
    disp(['    The error rate in the test set: ',num2str(100*errrat,'%1.4f'),'%.']);
end


%% show error samples

if ifdotest,
    errid = find(tefit~=telab);
    figure; 
for irow = 0:3,
    for iim = 1:min(3,length(errid)),
        isam = errid(irow*3+iim);
        subplot(4,6,irow*6+iim*2-1), ShowDigit(tesam(isam,:),['Sam. ',num2str(isam)],['label: ',num2str(telab(isam))]);
        pcarecovery = tesco(isam,:)*(coef(:,1:nodim)');
        subplot(4,6,irow*6+iim*2), ShowDigit(trmu+pcarecovery,['Rec. (',num2str(nodim),' PCs)'],['misclassified as ',num2str(tefit(isam))]);
    end
end
end

