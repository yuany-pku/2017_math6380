#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Mar 10 19:51:15 2017

@author: Xiao Ziliang(Leo)
"""



"""
Read me: 

Dear Prof. Yao, 
   Please use own path loading hand-written csv files.
   Then click on run!
   Hope you enjoy our code and report!
    
"""

import pandas as pd
import glob
import numpy as np
from sklearn.decomposition import PCA
from sklearn.linear_model import Lasso

##########################################
# Load dataset 
path = r'/Users/zephyr/Desktop/A mathematical introduction to data analysis'                     # use your own path
allFiles = glob.glob(path + "/*.csv")
frame = pd.DataFrame()
train = []
for file_ in allFiles:
    df = pd.read_csv(file_, header=None)
    train.append(df)






##########################################
# Data spliting

from sklearn.model_selection import train_test_split


X_train,X_test =[],[]
for i in range(10):
    train_result,test_result= train_test_split(train[i],test_size = 0.3,random_state =10)
    X_train.append(train_result)
    X_test.append(test_result)

X_mean  =[]
for i in range(10):
     X_mean.append(X_train[i].mean(axis = 0))
X_mean_1 = np.array(X_mean[1])


##########################################
# PCA

R2_lasso = []
pca = PCA(n_components=40, svd_solver='arpack')
test = (X_test[1][10:11].values-np.array(object =[X_mean_1])).T   # centralized test data



for i in range(10):
    pca.fit(X_train[i])
    Y = pca.components_;
    X = pd.DataFrame(data = [   (Y[0:40,d]) for d in range(256)       ])
    
    lasso = Lasso(alpha = 0.002,fit_intercept = False)
    lasso.fit(X,test)
    print("coef of number %s: %s" % (i,lasso.coef_) )
    print("R^2 with number %s: %s" %(i,lasso.score(X,test)))
    R2_lasso.append( lasso.score(X,test) )
    

R2_linear = []
for i in range(10):
    pca.fit(X_train[i])
    Y = pca.components_;
    X = pd.DataFrame(data = [   (Y[0:40,d]) for d in range(256)       ])
    
    lasso = Lasso(alpha = 0.0,fit_intercept = False)
    lasso.fit(X,test)
    print("coef of number %s: %s" % (i,lasso.coef_) )
    print("R^2 with number %s: %s" %(i,lasso.score(X,test)))
    R2_linear.append( lasso.score(X,test) )
    



X_df = []
for i in range(10):
    pca.fit(X_train[i])
    Y = pca.components_;
    X = pd.DataFrame(data = [   (Y[0:40,d]) for d in range(256)       ])
    X_df.append(X)


##########################################
# Plot function

import matplotlib.pyplot as plt


for i in range(25):
    plt.subplot(5,5,i+1)
    img_pca=np.reshape(Y[i,:],(16,16))
    imgshow=plt.imshow(img_pca,cmap='gray')


x = range(10)
y = R2_lasso
markerline, stemlines, baseline = plt.stem(x, y, '-.')
plt.setp(baseline, 'color', 'r', 'linewidth', 2)
plt.show()



x = range(10)
y = R2_linear
markerline, stemlines, baseline = plt.stem(x, y, '-.')
plt.setp(baseline, 'color', 'r', 'linewidth', 2)
plt.show()

# plot 
test = (X_test[1][10:11].values-np.array(object =[X_mean_1])).T   # centralized test data
lasso = Lasso(alpha = 0.002,fit_intercept = False)
lasso.fit(X_df[1],test)
plt.plot(lasso.coef_, color='gold', linewidth=2,
         label='Lasso coefficients')
lasso = Lasso(alpha = 0.0,fit_intercept = False)
lasso.fit(X_df[1],test)
plt.plot(lasso.coef_, '--', color='navy', label='Linear coefficients')
plt.legend(loc='best')
plt.show()




##########################################
# PCA for 8

R2_lasso = []
pca = PCA(n_components=40, svd_solver='arpack')
X_mean_8 = np.array(X_mean[8])
test = (X_test[8][15:16].values-np.array(object =[X_mean_8])).T   # centralized test data
for i in range(10):
    pca.fit(X_train[i])
    Y = pca.components_;
    X = pd.DataFrame(data = [   (Y[0:40,d]) for d in range(256)       ])
    
    lasso = Lasso(alpha = 0.002,fit_intercept = False)
    lasso.fit(X,test)
    print("coef of number %s: %s" % (i,lasso.coef_) )
    print("R^2 with number %s: %s" %(i,lasso.score(X,test)))
    R2_lasso.append( lasso.score(X,test) )


x = range(10)
y = R2_lasso
markerline, stemlines, baseline = plt.stem(x, y, '-.')
plt.setp(baseline, 'color', 'r', 'linewidth', 2)

plt.show()


#################################
# model checking accuracy
 




lasso = Lasso(alpha = 0.002,fit_intercept = False)

for k in range(10):
    temp = 0
    for j in range( len(X_test[k]) ): 
        R2_lasso = []
        test = (X_test[k][j:j+1].values-np.array(object =[np.array(X_mean[k])])).T 
        for i in range(10):
            lasso.fit(X_df[i],test) 
            R2_lasso.append( lasso.score(X_df[i],test) )
        if max(R2_lasso) == R2_lasso[k]:
            temp +=1
    print("accuracy for number %s: %s" % (k, temp/len(X_test[k]))   )
            
            
            
            
            
            
            
            
            
            

