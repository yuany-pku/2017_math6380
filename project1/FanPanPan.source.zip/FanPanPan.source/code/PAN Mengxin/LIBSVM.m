
time=zeros(10,1);

loop1=25;
loop2=20;
mse=zeros(loop2,loop1);

valimse=zeros(loop2,loop1);

tmse=zeros(loop2,loop1);

for j=1:loop1
t0=clock;

x = score_X(1:5832,1:10*j);
y = Train_Y(1:5832);

valix = score_X(5832:7291,1:10*j);

valiy = Train_Y(5832:7291);

testx=score_Y;
testy=Test_Y;


% train


    for i=1:loop2
        fprintf('iteration i: %d, j: %d \n', i,j);
       
        a=2^(2-0.5*i);
    
        cmd = ['-c ', num2str(a), ' -s 0 -t 0 '];
 
        model = libsvmtrain(y,x,cmd);
        

        [prey,premse,dec_values] = libsvmpredict(y,x,model);
        mse(i,j)=premse(1);
        
% validation

    
        [pretesty,pretmse,dec_values_test] = libsvmpredict(valiy,valix,model);

        valimse(i,j)=pretmse(1);

 % test
        
         [pretesty,pretmse,dec_values_test] = libsvmpredict(testy,testx,model);

        tmse(i,j)=pretmse(1);
        
    end
    
    time(j)=etime(clock,t0);
    
end

realtime=time/loop2;

