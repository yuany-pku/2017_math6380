function [ Y_pred, acc ] = pca_predict( X, model, Y )
%%  Prediction function of Digits Classifier basded on PCA
%   X is observations, model is the result of pca_train.
%   Default Y is the true label of X.
%%  Prediction
X = bsxfun(@times, X, 1./sqrt(sum(X.^2,2)));
score = nan(size(X,1),numel(model.label));
for i = 1:numel(model.label)
    score(:,i) = sum((X*model.coeff{i}(:,1:model.k)).^2,2);
end
[~, pos] = max(score, [], 2);

Y_pred = nan(size(X,1),1);
for i = 1:size(X,1)
    Y_pred(i) = model.label(pos(i));
end

% Accuracy
acc = mean(Y_pred == Y);

end