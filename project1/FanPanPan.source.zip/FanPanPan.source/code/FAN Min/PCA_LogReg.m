%%  Logistic Regression
Train = load('train');
Test = load('test');
Train_X = bsxfun(@minus,Train(:,2:end),mean(Train(:,2:end)));
Test_X = bsxfun(@minus,Test(:,2:end),mean(Train(:,2:end)));
Train_Y = Train(:,1);
Test_Y = Test(:,1);

[coeff, score, latent] = pca(Train_X);

[temp_X, ps] = mapminmax(score');
score_X = temp_X';
score_Y = Test_X*coeff;
temp_Y = mapminmax('apply', score_Y', ps);
score_Y = temp_Y';

pos_valid = floor(0.8*size(Train_X,1));
Train_label = double(nominal(Train_Y));
% [1 2 3 4 5 6 7 8 9 0] corresponds to [2 3 4 5 6 7 8 9 10 1]
label_train = Train_label(1:pos_valid,:);

score_train = score_X(1:pos_valid,:);
score_valid = score_X(pos_valid+1:end,:);
y_train = Train_Y(1:pos_valid,:);
y_valid = Train_Y(pos_valid+1:end,:);

k = [1 4 9 16 25 36 49 64];
num_k = numel(k);

acc_train = nan(num_k,1);
acc_valid = nan(num_k,1);
acc_test = nan(num_k,1);
time = nan(num_k,1);
for i = 1:num_k
    t = clock;
    fprintf('Iteration: %d.\n',i);
    [model, acc_train(i)] = Log_train(score_train(:,1:k(i)), label_train, y_train);
    [~, acc_valid(i)] = Log_pred(score_valid(:,1:k(i)), model, y_valid);
    [~, acc_test(i)] = Log_pred(score_Y(:,1:k(i)), model, Test_Y);
    time(i) = etime(clock,t);
    fprintf('Time used: %f.\n',time(i));
end
figure;
plot(k, acc_train, '--',...
    k, acc_valid, '-.',...
    k, acc_test, ':', 'LineWidth', 2);
title('Prediction Accuracy');
xlabel('The number of features');
ylabel('Percentage of the correct prediction');
legend('Train data','Validation data','Test data');
pos_best = nan(3,1);
[~, pos_best(1)] = max(acc_train);
[~, pos_best(2)] = max(acc_valid);
[~, pos_best(3)] = max(acc_test);

figure;
plot(k, time, 'r--', 'LineWidth', 2);
title('Time spent with different number of features');
xlabel('The number of features');
ylabel('Time');
