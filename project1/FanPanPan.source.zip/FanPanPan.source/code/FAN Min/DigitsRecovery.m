function [ handle ] = DigitsRecovery( X, coeff, k )
%%  Digits demonstration function for PCA
%   - X is one raw data of the digit.
%   - coeff is all principal components.
%   - k is a vector whoes elements represent the number of the principal
%   component used for recovery.
%   - handle is the handle of the figure.

num_rec = numel(k);
num_subplot = num_rec + 1;

handle = figure;
subplot(1,num_subplot,1);
imshow(reshape(X,[16 16])');
for i = 1:num_rec
    score = X*coeff(:,1:k(i));
    rec = score*coeff(:,1:k(i))';
    reshape_X = reshape(rec,[16 16])';
    subplot(1,num_subplot,i+1);
    imshow(reshape_X);
end

end

