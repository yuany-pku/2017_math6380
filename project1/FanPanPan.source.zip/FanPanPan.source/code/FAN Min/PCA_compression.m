%%  Compression
clear
clc
%   Loading Data and Centralization w.r.t. Training data
Train = load('train');
Test = load('test');
Train_X = bsxfun(@minus,Train(:,2:end),mean(Train(:,2:end)));
Test_X = bsxfun(@minus,Test(:,2:end),mean(Train(:,2:end)));
Train_Y = Train(:,1);
Test_Y = Test(:,1);

[coeff, score, latent] = pca(Train_X);
cum_var = zeros(numel(latent),1);
for i = 1:numel(latent)
    cum_var(i) =sum(latent(1:i))/sum(latent);
end
%   Plotting
plot(1:256, cum_var,'o','MarkerSize',3,...
    'MarkerEdgeColor','b','MarkerFaceColor','b');
axis([1 256 0 1]);
title('Cumulative Variance');
xlabel('The number of principal components');
ylabel('Percentage of cumulative variance w.r.t. total variance');
set(gca,'FontSize',12);

%%  Recovery from Compression based on PCA
num_train = size(Train_X,1);
k = [7 11 17 29 55];
for i = 1:4
    temp = randperm(num_train);
    chosen = temp(1);
    DigitsRecovery(Train_X(chosen,:), coeff, k);
end
