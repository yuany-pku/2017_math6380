%% Angle Method
Train = load('train');
Test = load('test');
% Train_X = Train(:,2:end);
% Test_X = Test(:,2:end);
Train_X = bsxfun(@minus,Train(:,2:end),mean(Train(:,2:end)));
Test_X = bsxfun(@minus,Test(:,2:end),mean(Train(:,2:end)));
Train_Y = Train(:,1);
Test_Y = Test(:,1);

pos_validation = floor(0.8*size(Train_X,1));
Train_data = Train_X(1:pos_validation,:);
Train_label = Train_Y(1:pos_validation,:);
Valid_data = Train_X(pos_validation+1:end,:);
Valid_label = Train_Y(pos_validation+1:end,:);

model_part = pca_train(Train_data, Train_label);
model = pca_train(Train_X, Train_Y);
acc_train = nan(256,1);
acc_valid = nan(256,1);
acc_test = nan(256,1);
time = nan(256,1);
for k = 1:256
    t = clock;
    fprintf('iteration: %d. \n',k);
    model_part.k = k;
    model.k = k;
    [~, acc_train(k)] = pca_predict(Train_data, model_part, Train_label);
    [~, acc_valid(k)] = pca_predict(Valid_data, model_part, Valid_label);
    [~, acc_test(k)] = pca_predict(Test_X, model, Test_Y);
    time(k) = etime(clock,t);
    fprintf('Time used: %f.\n',time(k));
end
figure;
plot(1:256, acc_train, 1:256, acc_valid, 1:256, acc_test);
title('Prediction Accuracy via Angle Method');
axis([1 256 0 1]);
xlabel('The number of principal components');
ylabel('Percentage of correct prediction');
legend('Train data','Validation data','Test data');
set(gca,'FontSize',12);
pos_best = nan(3,1);
[~, pos_best(1)] = max(acc_train);
[~, pos_best(2)] = max(acc_valid);
[~, pos_best(3)] = max(acc_test);

figure;
plot(1:256, time);
title('Time spent with different number of components');
xlabel('The number of principal components');
ylabel('Time');
set(gca,'FontSize',12);