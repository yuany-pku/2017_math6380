function [ model ] = pca_train( X, Y, k )
%%  Digits Classifier based on PCA
%   X is the data whose rows corrospond to observations.
%   Y is the label of observations. In the model which the function
%   returns, Y = 0 is used 10 to indicate.
%%  Initialization
%   Default k is 55 which achieves over 90% overall covariance.
if nargin == 2;
    k = 55;
end
model = struct();
%%  Training the classifier
num_label = numel(unique(Y));
coeff = cell(num_label,1);
cum_var = cell(num_label,1);
for i = 1: num_label
    [coeff{i}, latent, ~] = svd(X(Y==rem(i,10),:)');
    latent = diag(latent);
    cum_var{i} = zeros(numel(latent),1);
    for j = 1:numel(latent)
        cum_var{i}(j) = sum(latent(1:j))/sum(latent);
    end      
end
%%  Result
model.label = [1;2;3;4;5;6;7;8;9;0];
model.k = k;
model.mean_X = mean(X);
model.coeff = coeff;
model.cum_var = cum_var;

end

