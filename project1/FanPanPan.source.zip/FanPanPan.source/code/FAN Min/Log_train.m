function [ model, acc, pred_X ] = Log_train( score, Train_label, Train_Y)
%% Logistic Regression
[model, ~, ~] = mnrfit(score ,Train_label);
if nargin == 3
    %prediction of train data
    prob = mnrval(model,score);
    [~, pred_X] = max(prob, [], 2);
    acc = mean(double((pred_X-1)==Train_Y));
end
end