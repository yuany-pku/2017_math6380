function [ pred, acc ] = Log_pred( score, model, Train_Y )
%% Logistic Regression Prediction
prob = mnrval(model,score);
[~, pred] = max(prob, [], 2);
acc = mean(double((pred-1)==Train_Y));

end