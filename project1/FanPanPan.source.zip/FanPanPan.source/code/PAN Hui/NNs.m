load('PCA_data.mat');
num_class=10;
%preprocessing
Train_X=Train_X';
Test_X=Test_X';
num_test=length(Test_X);
num_train=length(Train_X);
Train_Y=Train_Y'+1;
Test_Y=Test_Y'+1;
Train_label_mtr=full(ind2vec(Train_Y,num_class));
Test_label_mtr=full(ind2vec(Test_Y,num_class));
train_pca=score_X';
test_pca=score_Y';
%parameter setup
trainFcn = 'trainbr';
hiddenLayerSize = [10,30,50,70,90,100];
train_acc=zeros(length(hiddenLayerSize),1);
test_acc=zeros(length(hiddenLayerSize),1);
train_pca_acc=zeros(length(hiddenLayerSize),1);
test_pca_acc=zeros(length(hiddenLayerSize),1);
%Training on Raw data
for i =1:length(hiddenLayerSize)
    net = patternnet(hiddenLayerSize(i));
    net.performFcn = 'crossentropy';
    net.input.processFcns = {'removeconstantrows','mapminmax'};
    net.output.processFcns = {'removeconstantrows','mapminmax'};
    % Setup Division of Data for Training, Validation, Testing
    net.divideFcn = 'dividerand';  
    net.divideMode = 'sample'; 
    net.divideParam.trainRatio = 80/100;
    net.divideParam.valRatio = 20/100;
    net.divideParam.testRatio = 0/100;  
    % Train the Network
    [net,tr] = train(net,Train_X,Train_label_mtr);
    % Test the Network
    test_prd= net(Test_X);
    train_prd=net(Train_X);
    test_grd_ind = vec2ind(Test_label_mtr);
    test_prd_ind = vec2ind(test_prd);
    test_acc(i) = sum(test_grd_ind == test_prd_ind)/numel(test_prd_ind);
    train_grd_ind = vec2ind(Train_label_mtr);
    train_prd_ind = vec2ind(train_prd);
    train_acc(i) = sum(train_grd_ind == train_prd_ind)/numel(train_prd_ind);
end
%Training on PCA data
for i =1:length(hiddenLayerSize)
    net_pca= patternnet(hiddenLayerSize(i));
    net_pca.performFcn = 'crossentropy';
    net_pca.input.processFcns = {'removeconstantrows','mapminmax'};
    net_pca.output.processFcns = {'removeconstantrows','mapminmax'};
    net_pca.divideFcn = 'dividerand'; 
    net_pca.divideMode = 'sample'; 
    net_pca.divideParam.trainRatio = 80/100;
    net_pca.divideParam.valRatio = 20/100;
    net_pca.divideParam.testRatio = 0/100;      
    % Train the Network
    [net_pca,tr0] = train(net_pca,train_pca,Train_label_mtr);
    % Test the Network
    test_pca_prd = net_pca(test_pca);
    train_pca_prd=net_pca(train_pca);    
    test_grd_ind = vec2ind(Test_label_mtr);
    test_prd_ind = vec2ind(test_pca_prd);
    test_pca_acc(i) = sum(test_prd_ind == test_grd_ind)/numel(test_grd_ind);
    train_grd_ind = vec2ind(Train_label_mtr);
    train_prd_ind = vec2ind(train_pca_prd);
    train_pca_acc(i) = sum(train_prd_ind == train_grd_ind)/numel(train_grd_ind);
end
figure1 = figure;
axes1 = axes('Parent',figure1);
box(axes1,'on');
hold(axes1,'all');
plot1 = plot(hiddenLayerSize,train_acc,hiddenLayerSize,test_acc);
set(plot1(1),'MarkerSize',4,'Marker','o','LineWidth',1,...
    'DisplayName',sprintf('train accuracy'));
set(plot1(2),'Marker','square','LineWidth',1,...
    'DisplayName',sprintf('test accuracy'));
xlabel('size of hidden layer');
ylabel('prediction accuracy');
legend1 = legend(axes1,'show');
axis([10 100 0.7 1]);
title('Neural network for raw data');

figure2 = figure;
axes2 = axes('Parent',figure1);
box(axes2,'on');
hold(axes2,'all');
plot2 = plot(hiddenLayerSize,train_pca_acc,hiddenLayerSize,test_pca_acc);
set(plot2(1),'MarkerSize',4,'Marker','o','LineWidth',1,...
    'DisplayName',sprintf('train accuracy'));
set(plot2(2),'Marker','square','LineWidth',1,...
    'DisplayName',sprintf('test accuracy'));
xlabel('size of hidden layer');
ylabel('prediction accuracy');
legend2 = legend(axes1,'show');
axis([10 100 0.7 1]);
title('Neural network for PCA');
