rm(list=ls())
setwd("/Users/vidal/Documents/MATH6380J/")
load("snp500.Rdata")

data = stockdata$data[1:1000,]
testing = stockdata$data[1001:1252,]
info = stockdata$info
colnames(data) <- info[,1]
colnames(testing) <- info[,1]
industries <- levels(as.factor(info[,2]))

pca <- list()
for(i in 1:length(industries)){
  data.i <- data[, colnames(data) %in% info[,1][info[,2]==industries[i]]]
  pca[[industries[i]]] <- prcomp(data.i, scale. = F)
  print(i)
}

pca[["All"]] <- prcomp(data)

require(stargazer)
stargazer(summary(pca[[1]])$importance[, 1:6])

# 1. Cumulative proportion of variance explained by PCs
importance <- c()
for(i in 1:(length(industries)+1)){
  importance.i = summary(pca[[i]])$importance[3, ]
  importance.i = c(importance.i, rep(1, 20))
  importance <- cbind(importance, importance.i[1:20])
}
colnames(importance) <- names(pca)
importance <- cbind(1:20, importance)
colnames(importance)[1] <- "Num"
importance <- as.data.frame(importance)

library("reshape2")
library("ggplot2")

plot.data <- melt(importance, id="Num")  # convert to long format
colnames(plot.data)[2] <- "Industry" 

ggplot(data=plot.data,
       aes(x=Num, y=value, colour=Industry)) + 
  geom_line() + 
  labs(title = "Cumulative Proportion of Variance Explained by Principle Components", 
       x="Number of P.C.", 
       y="Cumulative Proportion of Variance") +
  theme_bw() +
  theme(plot.title = element_text(hjust = 0.5))

# 2. first P.C. vs market/industry average
plots <- list()
for(i in 1:length(industries)){
  data.i <- data[, colnames(data) %in% info[,1][info[,2]==industries[i]]]
  rotation <- pca[[i]]$rotation
  pcs = scale(data.i, scale = F) %*% rotation
  pc1 = pcs[,1]
  ave = rowMeans(scale(data.i, scale = F))
  plot.data.i <- data.frame(pc1, ave)
  
  plots[[i]] <- ggplot(plot.data.i, aes(x=pc1, y=ave)) +
    geom_point(shape=1, color="red") +
    geom_smooth(method=lm) + 
    labs(title=industries[i],
      x="First Principle Component", 
      y="Industry Average") +
    theme_bw() +
    theme(plot.title = element_text(hjust = 0.5))
}

require(gridExtra)
grid.arrange(plots[[1]], plots[[2]], plots[[3]], plots[[4]], plots[[5]], 
             plots[[6]], plots[[7]], plots[[8]], plots[[9]], plots[[10]],
             ncol=2)

# 3. strategy
func <- function(k, pc1){
  output = lm(pc1~scale(data.i, scale = F)[(j-30):j,k]+0)
  return(mean(output$residuals))
}
load("functions.Rdata")

summary.trade.log <- function(x, y=dollarvolume) { # x is a matrix with rownames are dates.
  #y is the dollarvolume matrix that corresponds to x 
  
  x <- as.matrix(x)
  #if(zeroisna==T) x[x==0 & !is.na(x)] <- NA ##!!!!!! very important
  
  y[is.na(x)] <- NA  # then if no trade, the dollar volume becomes 0
  
  ## first : per trade returns
  pertrade.ret <- mean.narm(x)*250  ## Annualized per trade ret, easy to compare with daily ret.
  pertrade.sharpe <- mean.narm(x)/std.narm(x)*(250**.5)
  pertrade.hitrate <- sum(x>0 & !is.na(x))/sum(!is.na(x))
  pertrade.skewness <-  mean.narm((x-mean.narm(x))**3)/std.narm(x)**3
  pertrade.vol.median     <- median.narm(y)
  pertrade.ret.log.vol.weighted<- mean.narm(x*log(y))/mean.narm(log(y))
  
  pertrade <- c(pertrade.ret, pertrade.sharpe, pertrade.hitrate, pertrade.skewness, pertrade.vol.median,
                pertrade.ret.log.vol.weighted )
  
  
  #names(pertrade) <- c("Ann.Ret", "Sharpe", "Hit.rate", "skewness", "vol.median",
  #     "ret.log.vol.weighted" )
  
  ## second daily returns.
  daily.ret <- apply(x, 1, mean.narm)
  names(daily.ret) <- rownames(x)
  Ann.ret<- mean.narm(daily.ret)*250
  sharpe <- mean.narm(daily.ret)/std.narm(daily.ret)*(250**.5)
  hit.rate <- sum(daily.ret >0 & !is.na(daily.ret))/sum(!is.na(daily.ret))
  skewness <- mean.narm((daily.ret-mean.narm(daily.ret))**3)/std.narm(daily.ret)**3
  
  daily.vol <- apply(y, 1, sum.narm)
  daily.vol[daily.vol==0] <-NA
  daily.vol.median     <- median.narm(daily.vol)
  daily.ret.log.vol.weighted<- mean.narm(daily.ret*log(daily.vol))/mean.narm(log(daily.vol))
  
  daily <- c(Ann.ret, sharpe, hit.rate, skewness, daily.vol.median,   
             daily.ret.log.vol.weighted  )
  
  returns <- cbind(pertrade, daily)
  rownames(returns) <- c("Ann.Ret", "Sharpe", "Hit.rate", "skewness", "vol.median",
                         "ret.log.vol.weighted" )
  colnames(returns) <- c("per.trade", "daily")
  
  ## third: about trades:
  trades <- apply(!is.na(x), 1, sum)
  daily.trades.summary <- summary(trades)
  days.no.trade <- sum(trades==0)
  percent.days.no.trade  <- days.no.trade/nrow(x)
  
  NoTrades <- c(days.no.trade, percent.days.no.trade)
  names(NoTrades) <- c("days.no.trade", "percent.days.no.trade")
  
  ## ????  fourth: signal to return relations.
  ## ???? fifth: execution difficu  volume.summary <- summary()
  vol.threshold <- c(0.1, 0.5, 1, 5, 10, 1000)*10000000
  vol.threshold.lower <- c(0, 0.1, 0.5, 1, 5, 10)*10000000
  trades.by.vol <- return.by.vol <- numeric()
  for(i in 1:length(vol.threshold)) {
    idd <- (y < vol.threshold[i] & y > vol.threshold.lower[i] & !is.na(x))
    trades.by.vol[i] <- sum.narm(idd)
    return.by.vol[i] <- mean.narm(x[idd])  }
  returns.by.vol <- cbind(trades.by.vol, return.by.vol)
  colnames(returns.by.vol) <- c("trades", "returns")
  rownames(returns.by.vol) <- c("0-1m", "1m-5m","5m-10m","10m-50m","50m-100m","100m-..." )
  
  trades.threshold       <- c( 0, 2,  5, 10, 20, 50, 100, 100000 ) 
  trades.threshold.lower <- c(-1, 0,  2,  5, 10, 20, 50,  100) 
  days.by.trades <- days.by.trades.percent <- return.by.trades.temp <- numeric()
  for(i in 1:length(trades.threshold)) {
    idd1 <- (trades <= trades.threshold[i] & trades > trades.threshold.lower[i])
    days.by.trades[i] <- sum.narm(idd1)
    days.by.trades.percent[i] <-  days.by.trades[i]/nrow(x)
    return.by.trades.temp[i] <- mean.narm(daily.ret[idd1])  }
  returns.by.trades <- cbind( days.by.trades, return.by.trades.temp,  days.by.trades.percent)
  colnames(returns.by.trades) <- c("trading.days", "returns", "trading.days.percent")
  rownames(returns.by.trades) <- c("0", "1-2", "3-5","6-10","11-20","21-50","51-100", "101-..." )
  
  returns.by.vol.by.trades <-list()
  returns.by.vol.by.trades$by.vol <- returns.by.vol
  returns.by.vol.by.trades$by.trades <- returns.by.trades
  
  out <- list()
  out$returns <- returns 
  out$returns.by.volume <- returns.by.vol 
  out$returns.by.trades.per.day <- returns.by.trades
  out$daily.trades <- daily.trades.summary
  out$total.return <- sum.narm(daily.ret)
  # out$NoTrades <- NoTrades
  plot(daily.ret)
  out
}

plots <- list()
for(i in 1:length(industries)){
  data.i <- testing[, colnames(testing) %in% info[,1][info[,2]==industries[i]]]
  rotation <- pca[[i]]$rotation
  pcs = scale(data.i, scale = F) %*% rotation
  pc1 = pcs[,1]
  c2nextc <- pushforward(data.i)/data.i-1
  buy <- data.i*0
  for(j in 31:251){
    pc1.j <- pc1[(j-30):j]
    residuals <- sapply(1:ncol(data.i), func, pc1=pc1.j)
    buy[j, ] = -residuals
    print(j)
  }
  
  ret <- buy*c2nextc
  amt <- data.i*0+100
  
  summary.trade.log(ret, amt)
  daily.ret <- rowSums(apply(ret, 2, cumsum))/ncol(data.i)
  ave.ret <- rowSums(apply(c2nextc, 2, cumsum))/ncol(data.i)
  
  plot.data <- data.frame(date=1:252, strategy=daily.ret, industry.ave=ave.ret)
  plot.data <- melt(plot.data, id="date")  # convert to long format
  colnames(plot.data)[2] <- "Strategy"
  
  plots[[i]] <- ggplot(data=plot.data,
         aes(x=date, y=value, colour=Strategy)) + 
    geom_line() + 
    labs(title = industries[i], 
         x="Number of days", 
         y="Cumulative Return") +
    theme_bw() +
    theme(plot.title = element_text(hjust = 0.5))
  print(i)
}


grid.arrange(plots[[1]], plots[[2]], plots[[3]], plots[[4]], plots[[5]], 
             plots[[6]], plots[[7]], plots[[8]], plots[[9]], plots[[10]],
             ncol=2)