#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Fri Mar 10 15:01:58 2017

@author: Ruijian
"""
"/Users/Ruijian/Desktop/1111.csv"
import numpy as np
import pandas as pd
import math
import matplotlib.pyplot as plt
c = np.array(range(499))
r = np.genfromtxt("/Users/Ruijian/Desktop/1111.csv",delimiter=',',usecols=np.arange(0,5813))
rr = pd.read_csv("/Users/Ruijian/Desktop/1111.csv")
v = rr[[0]]
z = r[2:,2:]
U,s,V = np.linalg.svd(z)
def f_process_matric_U(matric_U,Save_N_Singular_value):
    """according to the matric U, choose the words as the feature in each document,根据前N个奇异值对U进行切分,选择前N列""" 
  
    document_matric_U=[]
    for line in matric_U:
        line_new=line[1:Save_N_Singular_value]
        document_matric_U.append(line_new)
    return document_matric_U
def f_process_matric_S(matric_S,Save_information_value):
    """choose the items with large singular value,根据保留信息需求选择奇异值个数"""
    matricS_new=[]
    S_self=0
    N_count=0
    Threshold=sum(matric_S)*float(Save_information_value)
    for value in matric_S:
        if S_self<=Threshold:
            matricS_new.append(value)
            S_self+=value
            N_count+=1
        else:
            break
    print ("the %dth largest singular values keep the %s information " %(N_count,Save_information_value))
    return (N_count,matricS_new)

def f_process_matric_V(matric_V,Save_N_Singular_value):
    """according to the matric V, choose the words as the feature in each document,根据前N个奇异值对U进行切分,选择前N行"""
    document_matric_V=matric_V[1:Save_N_Singular_value]
    return document_matric_V

def f_combine_U_S_V(matric_u,matric_s,matirc_v):
    """calculate the new document对奇异值筛选后重新计算文档矩阵"""
    
    new_document_matric=np.dot(np.dot(matric_u,np.diag(matric_s)),matirc_v)
    return new_document_matric

def f_matric_to_document(document_matric,word_list_self):
    """transform the matric to document,将矩阵转换为文档"""
    new_document=[]
    for line in document_matric:
        count=0
        for word in line:
            if float(word)>=0.9:                                                                                     #转换后文档中词选择的阈值
                new_document.append(word_list_self[count]+" ")
            else:
                pass
            count+=1
        new_document.append("\n")
    return new_document



"""计算,Save_infor_value = 比例值"""
N,S = f_process_matric_S(s,0.53)
""" use N to decide the shape of U and V"""
SS = S[1:len(S)]
UU = f_process_matric_U(U,N)
VV = f_process_matric_V(V,N)
""" use UU SS VV to get new information matrix"""
MM = f_combine_U_S_V(UU,SS,VV)
"""transform the matric to document,将矩阵转换为文档"""
df = pd.DataFrame(MM)
df.to_csv("/Users/Ruijian/Desktop/2222.csv")   
#MMM = f_matric_to_document(MM)
document = np.dot(np.diag(SS),VV)
word = np.dot(UU,np.diag(SS))
XXXX = np.transpose(document)


XX = np.array(XXXX)
""" CCC 是每一个都是81维向量，其中［0:499］是词向量，后面的都是文章向量"""
CCC = np.concatenate((word,XX))


"""选词：network（1），kernel（3），neurons（5），spike（7），layer（12），clustering（17），
loss（22），node（24），noise（25），classification（31），convex（32），latent（34），
posterior（35），gaussion（38），bayesian（39），regression（42），gradient（45），
synaptic（51），sparse（52），svm（62），recogintion（63），variantional（75），risk（77），
optimization（78），sampling（80），prediction（90），stochastic（96），local（102），
pca（115），markov（124），reinforcement（133），recurrent（137），spatial（146），filter（157）
lasso（159），spectral（162），entropy（165），threshold（169），iteration（171），conditional（178），
cortex（189），tensor（198），supervised（211），LDA（213），nonlinear（214），tree（225），
feedback（228），ICA（251），gibbs（253），adaptive(271), graphical(273), HMM(281),pixel(317),
Dirichlet(325),robot(341),embedding(347),channel(409), bandit(416),synapse(417),poisson(425),
logistic(440),quadratic(442),decomposite(462),unsuper(463),RBF(495),monte(498)"""
""" attention: minus 1!"""
m = np.transpose(CCC)
from sklearn.cluster import KMeans
zz = []
for x in [2,4,6,11,16,21,24,30,31,33,
34,37,38,41,62,74,76,77,89,95,101,114,123,132,136,145,156,158,161,164,168,170,
177,188,197,227,250,252,270,408,416,424,
439,441,461,462,494]:
    zz.append(CCC[x])
model = KMeans(n_clusters = 40)#,init = np.array(zz), n_init=1)
result=model.fit(CCC)

labels = model.labels_
r1 = pd.Series(labels).value_counts()
print model.inertia_
#距离越小 聚类效果越好
print (r1)
#for i in range(1,100,25):
   # model = KMeans(n_clusters=i)
   # s = model.fit(data)
   # print i , model.inertia_
#z = plt.scatter(x=result[:, 0], y=result[:, 1], c=labels)

model.labels_ 
M = pd.DataFrame(model.labels_[:500])
tt = np.concatenate([rr[[0]],M],axis=1)
MM = pd.DataFrame(tt)
ll = np.transpose(model.cluster_centers_)
MM.to_csv("/Users/Ruijian/Desktop/hhh111.csv")
document1=[]
for x in model.labels_[500:]:
    document1.append([x,0])
    
### rrrr is a good result.
rrrr = pd.read_csv("/Users/Ruijian/Desktop/good.csv",header = None)
rrrr = rrrr.applymap(np.int64)
rrr = pd.read_csv("/Users/Ruijian/Desktop/NIPS.csv")
mzz = list(rrr)
t1 = pd.DataFrame(mzz)
t1 = t1.iloc[1:5811,:]
final = np.concatenate([t1,rrrr],axis=1)
final = pd.DataFrame(final)
final.to_csv("/Users/Ruijian/Desktop/document-class.csv")
