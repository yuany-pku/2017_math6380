# -*- coding: utf-8 -*-
"""
Created on Sat Mar 11 19:53:58 2017

@author: Roger
"""

import numpy as np
import pandas as pd
import math
import matplotlib.pyplot as plt
from sklearn import svm

rr = pd.read_csv("NIPS_1987-2015.csv")
r = np.genfromtxt("NIPS_1987-2015.csv",delimiter=',')
y= r[1:,1:]
y.sum(axis=1)

def TFIDF(self):
    WordsPerDoc = self.sum(axis=0)
    
    DocsPerWord = np.asarray(self > 0,'i').sum(axis=1)
    
    rows,cols = self.shape
    yt = np.zeros((rows,cols))
    
    for i in range(rows):
        for j in range(cols):
            yt[i,j] = (self[i,j]/WordsPerDoc[j])*math.log(float(cols)/DocsPerWord[i])
    return yt

ytf = TFIDF(y)
#where_are_nan 
HH= np.isnan(ytf)
ytf[HH] = 0
a = ytf.sum(axis=1)
b = ytf.sum(axis=0)

'''Classify to CS:kernal(3) svm(62) recurrent(137)
   Classify to Stat:clustering(17) bayesian(39) stochastic(96) '''

#c = np.array(range(11463))
#plt.plot(a,c)
v = rr[[0]]
# combine tf-idf to original csv
df = rr.assign(tf=pd.Series(a))
dftf = df.sort('tf',ascending=False)
dftf.columns.values[0] = "word"
dftf = dftf.set_index('word')
top = dftf[0:150]
x1 = top.loc['kernel']
x2 = top.loc['svm']
x3 = top.loc['recurrent']
x4 = top.loc['clustering']
x5 = top.loc['bayesian']
x6 = top.loc['stochastic']
fea = top.loc[['kernel','svm','recurrent','clustering','bayesian','stochastic'],:]
del fea['tf']
setin = fea.sum(axis=0)>1
set = fea[fea.columns[setin]]
#training set 500
train = set.iloc[:,0:500]
tx = np.empty([500,6])
ty = np.empty([500,])
for i in range(500):
    tx[i,:] = train.values[:, i]
    if tx[i,0] + tx[i,1] + tx[i,2] > tx[i,3] + tx[i,4] + tx[i,5]:
        ty[i,] = 0 
    else:
        ty[i,] = 1
#svm
clf = svm.SVC()
clf.fit(tx, ty)
#test set
tn = set.shape[1]-500
testx = np.empty([tn,6])
for i in range(500, set.shape[1]):
    testx[i-500,:] = set.values[:, i]

res = clf.predict(testx)
np.set_printoptions(threshold='nan')
print(res).reshape(673,5)


# we only take the first two features. We could
#avoid this ugly slicing by using a two-dim dataset

h = .05  # step size in the mesh
tx2 = np.concatenate((tx[:,0].reshape((500,1)),tx[:,3].reshape((500,1))),axis=1)
# we create an instance of SVM and fit out data. We do not scale our
# data since we want to plot the support vectors
C = 1.0  # SVM regularization parameter
svc = svm.SVC(kernel='linear', C=C).fit(tx2, ty)
rbf_svc = svm.SVC(kernel='rbf', gamma=0.7, C=C).fit(tx2, ty)
poly_svc = svm.SVC(kernel='poly', degree=3, C=C).fit(tx2, ty)
lin_svc = svm.LinearSVC(C=C).fit(tx2, ty)

# create a mesh to plot in
x_min, x_max = tx[:, 0].min() - 1, tx[:, 0].max() + 1
y_min, y_max = tx[:, 3].min() - 1, tx[:, 3].max() + 1
xx, yy = np.meshgrid(np.arange(x_min, x_max, h),
                     np.arange(y_min, y_max, h))

# title for the plots
titles = ['SVC with linear kernel',
          'LinearSVC (linear kernel)',
          'SVC with RBF kernel',
          'SVC with polynomial (degree 3) kernel']


for i, clf in enumerate((svc, lin_svc, rbf_svc, poly_svc)):
    # Plot the decision boundary. For that, we will assign a color to each
    # point in the mesh [x_min, x_max]x[y_min, y_max].
    plt.subplot(2, 2, i + 1)
    plt.subplots_adjust(wspace=0.4, hspace=0.4)

    Z = clf.predict(np.c_[xx.ravel(), yy.ravel()])
#   Z = clf.predict(testx)
    # Put the result into a color plot
    Z = Z.reshape(xx.shape)
    plt.contourf(xx, yy, Z, cmap=plt.cm.coolwarm, alpha=0.8)

    # Plot also the training points
    plt.scatter(tx[:, 0], tx[:, 3], c=ty, cmap=plt.cm.coolwarm)
    plt.xlabel('Kernel')
    plt.ylabel('Clustering')
#    plt.legend()
    plt.xlim(xx.min(), xx.max())
    plt.ylim(yy.min(), yy.max())
    plt.xticks(())
    plt.yticks(())
    plt.title(titles[i])

fig = plt.gcf()
plt.show()
fig.savefig('svm_ker_clus.png', dpi=200)

    