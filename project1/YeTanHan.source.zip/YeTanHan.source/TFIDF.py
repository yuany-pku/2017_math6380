#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Thu Mar  9 11:50:00 2017

@author: Ruijian
"""

import numpy as np
import pandas as pd
import math
rr = pd.read_csv("/Users/Ruijian/Desktop/NIPS.csv")
r = np.genfromtxt("/Users/Ruijian/Desktop/NIPS.csv",delimiter=',')
y= r[1:,1:]
y.sum(axis=1)

def TFIDF(self):
    WordsPerDoc = self.sum(axis=0)
    
    DocsPerWord = np.asarray(self > 0,'i').sum(axis=1)
    
    rows,cols = self.shape
    yt = np.zeros((rows,cols))
    
    for i in range(rows):
        for j in range(cols):
            yt[i,j] = (self[i,j]/WordsPerDoc[j])*math.log(float(cols)/DocsPerWord[i])
    return yt

ytf = TFIDF(y)
#where_are_nan 
HH= np.isnan(ytf)
ytf[HH] = 0
a = ytf.sum(axis=1)
b = ytf.sum(axis=0)
import matplotlib.pyplot as plt
c = np.array(range(11463))
plt.plot(a,c)
v = rr[[0]]
df = pd.DataFrame(a,v)
df1 = pd.DataFrame(a)
df2 = pd.DataFrame(ytf)
tt = np.concatenate([df1,df2],axis=1)
#hhh=df.sort_values([0],ascending=False)
df = pd.DataFrame(tt,v)
hhh=df.sort_values([0],ascending=False)
ssr = hhh[0:500]
ssr.to_csv("/Users/Ruijian/Desktop/select_data.csv")