# Stepwise Forward variable selection, using L2 with different lambdas
# Implemented by Akhan Ismailov

import numpy as np
import cPickle as pickle
import random

avail_indexes = pickle.load(open('avail_indexes.p', 'rb'))
predict_indexes = pickle.load(open('predict_indexes.p', 'rb'))
cell_value = pickle.load(open('cell_value.p', 'rb '))
tmpmRNA = pickle.load(open('mRNA.p', 'rb'))
tmpCNV = pickle.load(open('CNV.p', 'rb'))

tmpComb = np.zeros((149, 18875+17771))
tmpComb[:, 0:18875] = tmpmRNA
tmpComb[:, 18875:] = tmpCNV

random.seed(1339)
shuf_arr = range(0, 129)
random.shuffle(shuf_arr)
train_size = 109

Y = cell_value[:, 2:]
Y_train = Y[shuf_arr[0:train_size], :]
Y_cross_val = Y[shuf_arr[train_size:], :]

lr = 1e-6
P = 36646

xs = tmpComb[avail_indexes, :][shuf_arr[0:train_size], :]
xs_cross_val = tmpComb[avail_indexes, :][shuf_arr[train_size:], :]
ys = Y_train
ys_cross_val = Y_cross_val

def solve_and_get_error(xs_local, ys, lam):
    xsTxs = np.linalg.pinv(np.matmul(xs_local.transpose(), xs_local) + lam * np.identity(xs_local.shape[1]))
    beta = np.matmul(np.matmul(xsTxs, xs_local.transpose()), ys)
    return np.mean(np.square( ys - np.matmul(xs_local, beta) ))

def get_error_for_vector_of_indexes(v_indexes, index, lam):
    v_indexes_new = v_indexes[:]
    v_indexes_new.append(index)
    return solve_and_get_error(xs[:, v_indexes_new], ys, lam)

def solve_and_get_beta(xs_local, ys, lam):
    xsTxs = np.linalg.pinv(np.matmul(xs_local.transpose(), xs_local) + lam * np.identity(xs_local.shape[1]))
    beta = np.matmul(np.matmul(xsTxs, xs_local.transpose()), ys)
    return beta

def get_error_cross_val(v_indexes, lam):
    beta = solve_and_get_beta(xs[:, v_indexes], ys, lam)
    return np.mean(np.square( ys_cross_val - np.matmul(xs_cross_val[:, v_indexes], beta) ))

lam_arr = [0.3, 0.03]
v_indexes = []

for lam in lam_arr:
    print '\n lambda:', lam
    v_indexes = []
    for iter in range(10):
        print iter
        min_index = -1
        min_value = -1
        for i in range(P):
            if i in v_indexes:
                continue
            rem1 = get_error_for_vector_of_indexes(v_indexes, i, lam)
            if i == 0 or rem1 < min_value:
                min_value = rem1
                min_index = i
        v_indexes.append(min_index)
        loss_cross_val = get_error_cross_val(v_indexes, lam)
        print 'loss training %f, loss cross val %f' % (min_value, loss_cross_val)

print v_indexes