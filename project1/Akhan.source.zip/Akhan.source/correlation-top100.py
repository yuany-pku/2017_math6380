# Find top 100 correlated variables in training and cross valid sets
# Print index of shared variables. Spoiler: prints only one
# Implemented by Akhan Ismailov

import numpy as np
import cPickle as pickle
import random

avail_indexes = pickle.load(open('avail_indexes.p', 'rb'))
predict_indexes = pickle.load(open('predict_indexes.p', 'rb'))
cell_value = pickle.load(open('cell_value.p', 'rb '))
tmpmRNA = pickle.load(open('mRNA.p', 'rb'))
tmpCNV = pickle.load(open('CNV.p', 'rb'))

tmpComb = np.zeros((149, 18875+17771))
tmpComb[:, 0:18875] = tmpmRNA
tmpComb[:, 18875:] = tmpCNV

random.seed(1339)
shuf_arr = range(0, 129)
random.shuffle(shuf_arr)
train_size = 109

Y = cell_value[:, 2:]
Y_train = Y[shuf_arr[0:train_size], :]
Y_cross_val = Y[shuf_arr[train_size:], :]

P = 36646

xs_train = tmpComb[avail_indexes, :][shuf_arr[0:train_size], :]
xs_cross_val = tmpComb[avail_indexes, :][shuf_arr[train_size:], :]

def correl(xs, ys):
    correlation = np.zeros(P)
    for i in range(P):
        correlation[i] = np.corrcoef(xs[:, i], ys[:, 0])[0][1]

    return correlation

def get_top_100(arr):
    return arr.argsort()[-100:][::-1]

correl_train = correl(xs_train, Y_train)
correl_cross_val = correl(xs_cross_val, Y_cross_val)

top_index_train = get_top_100(correl_train)
top_index_cross_val = get_top_100(correl_cross_val)

print correl_train[top_index_train]
print correl_cross_val[top_index_cross_val]

for i in range(len(top_index_train)):
    for j in range(len(top_index_cross_val)):
        if top_index_train[i] == top_index_cross_val[j]:
            print top_index_train[i]
            print correl_train[top_index_train[i]]
            print correl_cross_val[top_index_cross_val[i]]
# Only one printing occurs
# 7402
# 0.379205506336
# 0.738276053545