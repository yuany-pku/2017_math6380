# Main Algorithm
# linear regression for top 10 PCA components
# Implemented by Akhan Ismailov

import numpy as np
import cPickle as pickle
import random
from sklearn.decomposition import PCA

avail_indexes = pickle.load(open('avail_indexes.p', 'rb'))
predict_indexes = pickle.load(open('predict_indexes.p', 'rb'))
cell_value = pickle.load(open('cell_value.p', 'rb '))
tmpmRNA = pickle.load(open('mRNA.p', 'rb')) # 18875
tmpCNV = pickle.load(open('CNV.p', 'rb')) # 17771

tmpComb = np.zeros((149, 18875+17771))
tmpComb[:, 0:18875] = tmpmRNA
tmpComb[:, 18875:] = tmpCNV

random.seed(1339)
shuf_arr = range(0, 129)
random.shuffle(shuf_arr)
train_size = 109

Y = cell_value[:, 2:]
Y_train = Y[shuf_arr[0:train_size], :]
Y_cross_val = Y[shuf_arr[train_size:], :]

n_components = 10
lr = 1e-6

pca = PCA(n_components=n_components)
pca.fit(tmpComb)
Components = pca.components_
Comb = np.matmul(tmpComb, Components.transpose())
Comb_train = Comb[avail_indexes, :][shuf_arr[0:train_size], :]
Comb_cross_val = Comb[avail_indexes, :][shuf_arr[train_size:], :]
Comb_test = Comb[predict_indexes, :]

W1 = np.zeros((n_components, 1))
min_val_loss = 100.
min_train_loss = 100.
num_iters = 100 * 1000

counter_unchanged = 0

for iter in range(num_iters):
    ys = np.matmul(Comb_train, W1)
    dys = ys - Y_train
    dys /= train_size
    dW1 = np.matmul(Comb_train.transpose(), dys)
    W1 -= lr * dW1

    if iter % 1 == 0:
        loss_train = np.mean(np.square(Y_train - ys))
        loss_val = np.mean(np.square( Y_cross_val - np.matmul(Comb_cross_val, W1) ))
        if iter % 100 == 0:
            print iter, loss_train, loss_val
        if min_val_loss < loss_val:
            counter_unchanged += 1
        else:
            counter_unchanged = 0
        min_val_loss = min(min_val_loss, loss_val)

    if counter_unchanged == 100:
        print 'converged at iter %d, with val loss %f' % (iter, min_val_loss)
        break

ys_test = np.matmul(Comb_test, W1)

print '\n\nindex,IC50_72hrs'
for i in range(len(predict_indexes)):
    print '%d,%.4f' % (predict_indexes[i] + 1, ys_test[i])

