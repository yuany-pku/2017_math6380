There is no preprocessed data of csv files that I am using in python code.
If necessary I can provide it.
Although it is possible to understand what code does, without running it.
