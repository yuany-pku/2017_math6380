# This turn out to be bad results

import pandas as pd
import io, requests
import numpy as np
import matplotlib as plt
from sklearn.decomposition import PCA,SparsePCA
from sklearn import preprocessing
import math

# read csvs
c = pd.read_csv('crimedata2.csv')
data = np.array(c)
data = data[1:,2:]
data = np.array(data,dtype='float32')
data = preprocessing.scale(data)
print data.shape

for i in range(1050):
    for j in range(31):
        p = data[i][j]
        if np.isnan(p) or np.isinf(p):
            print i
            print j
#        if j == 6:
            # data[i][j] = data[i][j] / 10000000
            # print data[i][j]
# PCA
# data = preprocessing.scale(data)
pca = PCA(n_components=6)
pca.fit(data)
print pca.explained_variance_ratio_

Y = pca.components_;
#print Y