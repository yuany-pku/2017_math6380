addpath(genpath('data'));
addpath(genpath('code'));
s=[65,126,230,31,101,46,236,16,102,140,135,49,120,219,152,170,28,194,29,20,158,228,132,224,63,184,124,113,157,6,173,146,153,210,214,104,127,30,17,220,87,203,198,15,38,171,43,90,32,209,25,180,168,52,138,185,151,213,212,145,13,231,88,142,112,89,55,96,116,221,35,11,123,53,40,110,188,159,84,62,45,56,183,128,189,12,81,27,3,211,164,160,76,147,4,100,39,187,149,99];
sourcename = 'coauthorAdjThreshGiant.txt';
fidin=fopen( 'authorListCoauthorThreshGiant.txt','r');  
adj=load(sourcename);
len=length(adj);
names = cell(1,len);
i=1;
while ~feof(fidin) 
    tline=fgetl(fidin);
    names{i}=char(tline);
    i=i+1;
end
fclose(fidin);
%% Open the text file.
name=cell(1,length(s));
for i =1:length(s)
    name{i}=names{s(i)};
end

adj_sub = subgraph(adj,s);
G=graph(adj_sub,name);
deg = degree(G);
nSizes =5*sqrt(deg-min(deg)+0.2);
nColors = deg;
figure,
colormap hsv
plot(G,'MarkerSize',nSizes,'NodeCData',nColors,'EdgeAlpha',0.5)
colorbar
title('Community in threshold giant commonent network (100 nodes)')
