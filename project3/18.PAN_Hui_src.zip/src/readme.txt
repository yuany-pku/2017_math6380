load_preprocess.m               -load the adjacency matrix and calculate the links from it. 
statistic_feature_extractor.m               -calculate the main statistical measures of network.
community_visualize.m               -build the network of communities detected from the whole network and visualize it.

To minimize the size of source file, it only contians partial data for easy demonstration.
You can download the whole datatset from the below website and unzip it in the /data file.
Web:
http://math.stanford.edu/~yuany/course/data/jiashun/Jiashun.zip
Reference: 
P. Ji and J. Jin. Coauthorship and citation networks for statisticians. Ann. Appl. Stat. Volume 10, Number 4 (2016), 1779-1812.
Bounova, G., de Weck, O.L. Overview of metrics and their correlation patterns for multiple-metric topology analysis on heterogeneous graph ensembles. Phys. Rev. E 85, 016117 (2012).