targetname = {'coauthorLinkThreshGiant', 'coauthorLinkGiant', 'coauthorLink'};
tail='.csv';
delimiter = ',';
formatSpec = '%d%d%[^\n\r]';
for i= 1:length(targetname)
    fileID = fopen(strcat(targetname{i},tail) ,'r');
    dataArray = textscan(fileID, formatSpec, 'Delimiter', delimiter, 'EmptyValue' ,NaN, 'ReturnOnError', false);
    fclose(fileID);
    mtr = [dataArray{1:end-1}];
    clearvars  fileID dataArray;
    [h edgeList]= histcounts(mtr(:),unique(mtr(:)));
    sort_h=sort(h,'descend');
    top50 = edgeList(ismember(h,sort_h(1:50)));
    top10 = edgeList(ismember(h,sort_h(1:10)));
    top5 = edgeList(ismember(h,sort_h(1:5)));
    save(strcat(targetname{i},'_influential_author.mat'),'top10','top5','top50');
    f=figure;
    f.Name=targetname{i};
    histogram(h)
    title(targetname{i})
end