addpath(genpath('data'));
%% Import data from text file.
sourcename = {'coauthorAdjThreshGiant.txt', 'coauthorAdjGiant.txt', 'coauthorAdj.txt'};
targetname = {'data/coauthorLinkThreshGiant.mat', 'data/coauthorLinkGiant.mat', 'data/coauthorLink.mat'};
%% Open the text file.
for i= 1:length(sourcename)
    mtr = load(sourcename{i});   
    [source,target]=find(mtr);
    links=[min(source,target),max(source,target)];
    link=unique(links,'rows');
    save( targetname{i}, 'link');
end

sourcename = {'authorCitAdj.txt', 'authorCitAdjGiant.txt'};
targetname = {'authorCitlink.mat', 'authorCitLinkGiant.mat'};
for i= 1:length(sourcename)
    mtr = load(sourcename{i});
    [row,col]=find(mtr);
    links=[col,row];
    link=unique(links,'rows');
    save( targetname{i}, 'link');
end

        
    
    