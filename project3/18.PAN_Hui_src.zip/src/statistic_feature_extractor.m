%% Import data from text file.
addpath(genpath('data'));
addpath(genpath('code'));
sourcename = {'coauthorAdjThreshGiant', 'coauthorAdjGiant', 'coauthorAdj'};
tail='.txt';
%% Open the text file.
for i= 1:length(sourcename)
    adj =  load(strcat(sourcename{i},'.txt'));
    % Calculate the number of connected components using the Laplacian
    nc=num_conn_comp(adj);
    %extract connected components 
    comp_mat = find_conn_comp(adj); 
    % extract giant component from a network
    [GC,gc_nodes]=giant_component(adj);
    
    %community detect
    [groups_hist,Q]=newman_comm_fast(adj);
    modules1=newman_eigenvector_method(adj);
    k=100;
    [modules2,module_hist,Q2] = newmangirvan(adj,k);
    modules3 = simple_spectral_partitioning(adj,k);
    [modules4,inmodule] = louvain_community_finding(adj);
        
    clsn = closeness(adj) ;
    dgr= degrees(adj);
    ave_nei_deg = ave_neighbor_deg(adj) ;
    % The number of pairs of nodes at a distance x, divided by the total number of pairs n(n-1)
    % OUTPUTS: distribution vector ((n-1)x1): {k_i} where k_i is the # of pairs at a distance i, normalized
    ddist=distance_distribution(adj);
    
    % The minimum vertex eccentricity is the graph radius
    Rg=graph_radius(adj);
    %S=graph_similarity(A,B);
    % Betweenness centrality measure: number of shortest paths running though a vertex 
    btwn = node_betweenness_faster(adj);
   
    I=sort_nodes_by_sum_neighbor_degrees(adj);
    I2=sort_nodes_by_max_neighbor_degree(adj);
    %adj_sub = subgraph(adj,S);
    
    save(strcat(sourcename{i},'_result0.mat'),'clsn','dgr','ave_nei_deg','ddist','Rg','btwn','ew','nc','comp_mat');
    save(strcat(sourcename{i},'_result1.mat'),'GC','gc_nodes','modules1','modules3','modules4','inmodule');
end
    
    
    