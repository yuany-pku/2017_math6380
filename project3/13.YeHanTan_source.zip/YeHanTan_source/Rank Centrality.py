#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Tue May  9 15:17:58 2017

@author: Ruijian
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.preprocessing import scale
from sklearn import linear_model, cross_validation, preprocessing
from sklearn.linear_model import Ridge, RidgeCV, Lasso, LassoCV
from sklearn.metrics import mean_squared_error
from scipy import stats
import statsmodels.api as sm
from collections import Counter

df = pd.read_csv("/Users/Ruijian/Desktop/college1.csv")
X= df['Winner_Text']
Y= df['Loser Text']
Z=[]
ZZ = []
for x in X:
    if x not in Z:
        Z.append(x)
for y in Y:
    if y not in Z:
        Z.append(y)
#Z college name and number
z = pd.DataFrame(Z)
zz = pd.DataFrame(ZZ)
pd.DataFrame.to_csv(z,"/Users/Ruijian/Desktop/college11.csv")
df1 = df[['Winner_Text','Loser Text']]
np1 = np.array(df1)
list1 = np.ndarray.tolist(np1)
# count function
def f(i,j):
    return list1.count([i,j])
A =  np.zeros((261, 261)) 
for i in range(261):
    for j in range(261):
        A[i][j] = f(Z[i],Z[j])
#matrix A 
#np.savetxt("foo.csv", A, delimiter=",")

#matrix B
B =  np.zeros((261, 261))
for i in range(261):
    for j in range(261):
        if A[i][j] + A[j][i] == 0:
            B[i][j] = 0
            #B[i][j] = np.exp(A[i][j])/(np.exp(A[i][j])+ np.exp(A[j][i]))
        else:
            B[i][j] = A[j][i]/(A[i][j]+ A[j][i])


np.savetxt("foo11.csv", B, delimiter=",")
np.count_nonzero(B)
#transition matrix C
#sorted(np.sum(B,axis=1), reverse = True)
d = np.sum(B, axis = 1)
C = np.zeros((261, 261))
dmax = 65
#for i in range(261):
    #for j in range(261):
        #if i != j:
            #C[i][j] = B[i][j]/d[i]
            #B[i][j] = np.exp(A[i][j])/(np.exp(A[i][j])+ np.exp(A[j][i]))
        #else:
            #C[i][j] = 0
#dd = np.sum(C, axis = 1)

for i in range (261):
    for j in range (261):
        if i != j:
           C[i][j] = B[i][j]/dmax
        else:
            C[i][j] = 0
cc = np.sum(C,axis=1)
for i in range(261):
    C[i][i] = 1 - cc[i]
        


#CC = np.sum(C,axis=1)
#for i in range(261):
   # C[i][i] = 1 - CC[i]
p = np.ones(261)    
import numpy as np
from scipy.linalg import eig 
transition_mat = np.matrix(C)

S, U = eig(transition_mat.T)
ss = np.array(U[:, np.where(np.abs(S - 1.) < 1e-12)[0][0]].flat)
ssss = np.zeros(261)
for i in range(261):
    ssss[i] = ss[i].real
      
sss = pd.DataFrame(ssss)
np.savetxt("foooo.csv", sss, delimiter=",")

tt = pd.concat([z,sss],axis =1)
tt.columns = ['college', 'value']
Answer1 = tt.sort_values('value',ascending = False)
pd.DataFrame.to_csv(Answer1,"/Users/Ruijian/Desktop/Answer1.csv")