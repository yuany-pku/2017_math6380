# -*- coding: utf-8 -*-
"""
Created on Thu May 18 20:22:48 2017

@author: Roger
"""
#%%
from __future__ import division
import os 
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import statsmodels.api as sm
from scipy.stats import norm
from trueskill import *
import operator
import csv

print os.getcwd()
#%%
da = pd.read_csv('college.csv')
print da.shape, da.columns
da['Winner Text'].value_counts()
#college name == 261
clg = da['Winner Text'].unique()
#response time to use as draw probability
restm = da['Response Time (s)']
#x = np.arange(len(restm))
#plt.scatter(x, restm)

#create dict of colleges and ratings
rclg = {}
k = 0
while k < len(clg):
    #<dynamically create key> 
    key = clg[k]
    #<calculate value> 
    value =  Rating()
    rclg[key] = value 
    k += 1
#update ratings    
n = 0
for n in range(0, len(da)):
    w = da.ix[n]['Winner Text']
    l = da.ix[n]['Loser Text']
    rclg[w], rclg[l]= rate_1vs1(rclg[w], rclg[l])
    n += 1

sort_clg = sorted(rclg.items(), key=operator.itemgetter(1), reverse = True)

with open('rclg.csv', 'wb') as csv_file:
    writer = csv.writer(csv_file)
    for key, value in rclg.items():
       writer.writerow([key, value])
#%%
#draw normal curves to visualize
fig = plt.figure(figsize=(12,10), dpi=100, facecolor='w', edgecolor='k')
ax = fig.add_subplot(1,1,1)
top5 = sort_clg[0:5]
x = np.linspace(28, 44, 500)
y1 = norm.pdf(x, loc = top5[0][1].mu, scale = top5[0][1].sigma)
y2 = norm.pdf(x, loc = top5[1][1].mu, scale = top5[1][1].sigma)
y3 = norm.pdf(x, loc = top5[2][1].mu, scale = top5[2][1].sigma)
y4 = norm.pdf(x, loc = top5[3][1].mu, scale = top5[3][1].sigma)
y5 = norm.pdf(x, loc = top5[4][1].mu, scale = top5[4][1].sigma)
ax.plot(x, y1, 'blue', label = top5[0][0], linewidth = 1.5)
ax.plot(x, y2, 'orange', label = top5[1][0], linewidth = 1.5)
ax.plot(x, y3, 'black', label = top5[2][0], linewidth = 1.5)
ax.plot(x, y4, 'brown', label = top5[3][0], linewidth = 1.5)
ax.plot(x, y5, 'magenta', label = top5[4][0], linewidth = 1.5)
ax.legend(loc = 'best')
fig.savefig('top5clg.png', dpi=200)
#%%
#draw graph of trend of mu and sigma
figg = plt.figure(figsize=(16,8), dpi=100)
ax1 = figg.add_subplot(1,2,1)
ax2 = figg.add_subplot(1,2,2)
xx = np.linspace(1, len(clg)+1, len(clg))
i = 0
clgmu = []
for i in range(0, len(sort_clg)):
    clgmu.append(sort_clg[i][1].mu)
    i +=1
clgsgm= []
for i in range(0, len(sort_clg)):
    clgsgm.append(sort_clg[i][1].sigma)
    i +=1
ax1.plot(xx, clgmu, 'brown', linewidth = 1.5)
ax1.set_xlim([1,262])
ax1.set_xlabel('Colleges')
ax1.set_title('Trend of Mu Value of Colleges')
ax2.plot(xx, clgsgm, 'orange', linewidth = 1.5)
ax2.set_xlim([1,262])
ax2.set_title('Trend of Sigma Value of Colleges')
ax2.set_xlabel('Colleges')
plt.subplots_adjust(wspace = 0.08, hspace=0)
figg.savefig('mu_sigma,png', dpi=200)


qua1 = quality_1vs1(sort_clg[3][1], sort_clg[53][1])
qua2 = quality_1vs1(sort_clg[3][1], sort_clg[103][1])
qua3 = quality_1vs1(sort_clg[103][1], sort_clg[53][1])

#trueskill example
#r1 = Rating()
#r2 = Rating()
#print('{:.1%} chance to draw'.format(quality_1vs1(r1,r2)))
#new_r1, new_r2 = rate_1vs1(r1, r2)
#print new_r1, new_r2