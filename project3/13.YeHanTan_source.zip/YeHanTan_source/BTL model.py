#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Fri May 19 15:02:58 2017

@author: tanchunxi
"""


import pandas as pd
import numpy as np
import math
import matplotlib.pyplot as plt
from sklearn.preprocessing import scale
from sklearn import linear_model, cross_validation, preprocessing
from sklearn.linear_model import Ridge, RidgeCV, Lasso, LassoCV
from sklearn.metrics import mean_squared_error
from scipy import stats
import statsmodels.api as sm
from collections import Counter

df = pd.read_csv("/Users/tanchunxi/Desktop/college.csv")
X= df['Winner_Text']
Y= df['Loser Text']
Z=[]
ZZ = []
for x in X:
    if x not in Z:
        Z.append(x)
for y in Y:
    if y not in Z:
        Z.append(y)
#Z college name and number
z = pd.DataFrame(Z)
zz = pd.DataFrame(ZZ)
pd.DataFrame.to_csv(z,"/Users/tanchunxi/Desktop/college11.csv")
df1 = df[['Winner_Text','Loser Text']]
np1 = np.array(df1)
list1 = np.ndarray.tolist(np1)
# count function
def f(i,j):
    return list1.count([i,j])
A =  np.zeros((261, 261)) 
for i in range(261):
    for j in range(261):
        A[i][j] = f(Z[i],Z[j])
#matrix A 
#np.savetxt("foo.csv", A, delimiter=",")
#生成一个comparision的矩阵

from scipy.optimize import minimize
import scipy.stats as stats

#def lf(u):
   # loglik =0
    #for i in range(261):
        #for j in range(261):
            #loglik += -A[i][j]*math.log(stats.norm.cdf(u[i]-u[j]))
    #return loglik
#m = np.zeros(261)
#def q(u):
    #t=0
    #for i in range(261):
        #t += u[i]
    #return t
#def con_real(t):
    
    #return np.sum(np.iscomplex(t))
#cons = [{'type':'eq', 'fun': q}]
#hhh=minimize(lf,m,method ='SLSQP',constraints=cons)
C = np.zeros((261,261))
for i in range(261):
    for j in range(261):
            C[i,j] = np.exp(A[i,j])-0.5
D = np.zeros((261,261))
for i in range(261):
    for j in range(261):
            D[i,j] = np.log(C[i,j]/(C[i,j]+C[j,i]))-np.log(1-(C[i,j]/(C[i,j]+C[j,i])))
#HHH=pd.DataFrame(hhh)
u = np.zeros(261)
for i in range(261):
    for j in range(261):
        u[i] += D[i,j]
uu = pd.DataFrame(u)
hh = pd.concat([z,uu],axis =1)
hh.columns = ['college', 'value']
Answer2 = hh.sort_values('value',ascending = False)
pd.DataFrame.to_csv(Answer2,"/Users/tanchunxi/Desktop/Answer2.csv")
    

    





